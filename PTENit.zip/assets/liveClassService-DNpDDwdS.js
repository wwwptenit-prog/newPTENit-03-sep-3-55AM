import{w as m}from"./index-BYH0Clei.js";/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]],w=m("calendar",N);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $=[["path",{d:"M16.247 7.761a6 6 0 0 1 0 8.478",key:"1fwjs5"}],["path",{d:"M19.075 4.933a10 10 0 0 1 0 14.134",key:"ehdyv1"}],["path",{d:"M4.925 19.067a10 10 0 0 1 0-14.134",key:"1q22gi"}],["path",{d:"M7.753 16.239a6 6 0 0 1 0-8.478",key:"r2q7qm"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]],M=m("radio",$);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],g=m("shield",f);function d(e){if(!e.date||!e.time)return"scheduled";try{const[i,n,a]=e.date.split("-").map(Number),[r,c]=e.time.split(":").map(Number);if(isNaN(i)||isNaN(n)||isNaN(a)||isNaN(r)||isNaN(c))return"scheduled";const t=new Date(i,n-1,a,r,c,0,0).getTime(),u=e.durationMinutes&&e.durationMinutes>0?e.durationMinutes:90,h=t+u*60*1e3,o=Date.now();return o<t?"scheduled":o>=t&&o<=h?"live_now":"expired"}catch{return"scheduled"}}function k(e){return Array.isArray(e)?e.filter(n=>d(n)!=="expired").sort((n,a)=>{const r=d(n),c=d(a);if(r==="live_now"&&c!=="live_now")return-1;if(c==="live_now"&&r!=="live_now")return 1;const s=new Date(`${n.date}T${n.time||"00:00"}:00`).getTime()||0,t=new Date(`${a.date}T${a.time||"00:00"}:00`).getTime()||0;return s-t}):[]}function _(e,i){try{const[n,a,r]=e.split("-"),[c,s]=(i||"20:00").split(":"),t=parseInt(c,10),u=parseInt(s,10),h=t>=12,o=t%12===0?12:t%12,l=t>=5&&t<12?"সকাল":t>=12&&t<16?"দুপুর":t>=16&&t<19?"বিকাল":"রাত",p=`${r}/${a}/${n}`,y=`${l} ${o.toLocaleString("bn-BD")}:${u<10?"০":""}${u.toLocaleString("bn-BD")} মি.`;return`${p} (${y})`}catch{return`${e} ${i}`}}export{w as C,M as R,g as S,d as a,_ as f,k as g};
