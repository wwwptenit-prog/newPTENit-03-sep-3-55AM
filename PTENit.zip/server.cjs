var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_compression = __toESM(require("compression"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var app = (0, import_express.default)();
var PORT = 3e3;
app.use((0, import_compression.default)());
app.use(import_express.default.json());
var getAiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new import_genai.GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build"
      }
    }
  });
};
var generateWithFallback = async (ai, contents, config) => {
  const modelsToTry = [
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
    "gemini-2.0-flash",
    "gemini-3.1-flash-lite",
    "gemini-3.7-flash",
    "gemini-flash-latest"
  ];
  let lastErr = null;
  for (const m of modelsToTry) {
    try {
      const reqOptions = { model: m, contents };
      if (config) reqOptions.config = config;
      const res = await ai.models.generateContent(reqOptions);
      if (res && res.text) {
        return res;
      }
    } catch (err) {
      lastErr = err;
      console.warn(`Model ${m} encountered ${err?.status || "issue"}, switching to fallback model...`);
    }
  }
  throw lastErr || new Error("All Gemini model attempts completed");
};
app.post("/api/gemini/optimize-order", async (req, res) => {
  try {
    const { roughTitle, category, description } = req.body;
    const ai = getAiClient();
    if (!ai) {
      const cleanTitle = roughTitle ? roughTitle.trim() : "Digital Service";
      return res.json({
        optimizedTitle: `I will ${cleanTitle} for Order Boss Marketplace`,
        optimizedDesc: `\u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u09AC\u09B8 \u09AA\u09CD\u09B2\u09CD\u09AF\u09BE\u099F\u09AB\u09B0\u09CD\u09AE\u09C7 \u098F\u0987 \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8\u099F\u09BF \u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8! ${description || "\u0989\u099A\u09CD\u099A\u09AE\u09BE\u09A8\u09C7\u09B0 \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8 \u0993 \u09E8\u09EA \u0998\u09A3\u09CD\u099F\u09BE\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u098F\u0995\u09CD\u09B8\u09AA\u09CD\u09B0\u09C7\u09B8 \u09A1\u09C7\u09B2\u09BF\u09AD\u09BE\u09B0\u09BF\u0964"}

\u{1F31F} \u0995\u09C7\u09A8 \u098F\u0987 \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8 \u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u0995\u09B0\u09AC\u09C7\u09A8:
- \u09E7\u09E6\u09E6% \u09B8\u09CD\u09AF\u09BE\u099F\u09BF\u09B8\u09CD\u09AB\u09C7\u0995\u09B6\u09A8 \u0997\u09CD\u09AF\u09BE\u09B0\u09BE\u09A8\u09CD\u099F\u09BF
- \u09A6\u09CD\u09B0\u09C1\u09A4 \u09B0\u09BF\u09AD\u09BF\u09B6\u09A8 \u0993 \u09AA\u09CD\u09B0\u09AB\u09C7\u09B6\u09A8\u09BE\u09B2 \u09AB\u09BE\u0987\u09B2
- \u09E8\u09EB/\u09ED \u0995\u09BE\u09B8\u09CD\u099F\u09AE\u09BE\u09B0 \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F`,
        tags: [category || "Programming", "Order Boss", "Top Rated", "Expert Service", "Fast Delivery"]
      });
    }
    const prompt = `You are Order Boss AI Assistant (\u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u09AC\u09B8 \u098F\u0986\u0987 \u09B8\u09B9\u0995\u09BE\u09B0\u09C0). 
A freelancer wants to publish an order (service) on Order Boss marketplace.
Title provided: "${roughTitle || ""}"
Category: "${category || "Programming & Tech"}"
Description/Notes provided: "${description || ""}"

Generate an expert, high-converting SEO optimized title, description, and tags.
Return ONLY a raw valid JSON object without markdown formatting:
{
  "optimizedTitle": "Catchy SEO title in English or mixed English/Bangla starting with 'I will...' or '\u0986\u09AE\u09BF...' (max 80 chars)",
  "optimizedDesc": "Engaging detailed description in Bangla & English with bullet points, why choose us, and deliverables.",
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"]
}`;
    const response = await generateWithFallback(ai, prompt, {
      responseMimeType: "application/json"
    });
    const textOutput = response.text || "{}";
    const parsed = JSON.parse(textOutput);
    return res.json(parsed);
  } catch (err) {
    console.error("Gemini Optimization error:", err);
    return res.json({
      optimizedTitle: `I will provide professional ${req.body.roughTitle || "custom service"} on Order Boss`,
      optimizedDesc: `\u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u09AC\u09B8 \u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09AA\u09CD\u09B2\u09C7\u09B8\u09C7 \u09AA\u09C7\u09B6\u09BE\u09A6\u09BE\u09B0 \u09A1\u09C7\u09B2\u09BF\u09AD\u09BE\u09B0\u09BF \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8\u0964
- \u09A6\u09CD\u09B0\u09C1\u09A4 \u09A1\u09C7\u09B2\u09BF\u09AD\u09BE\u09B0\u09BF
- \u09E7\u09E6\u09E6% \u09B8\u09A8\u09CD\u09A4\u09C1\u09B7\u09CD\u099F\u09BF
- \u09B2\u09BE\u0987\u09AB\u099F\u09BE\u0987\u09AE \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F`,
      tags: ["Order Boss", "Freelance Pro", "Top Service", "Fast Delivery", "Expert Work"]
    });
  }
});
app.post("/api/gemini/chat", async (req, res) => {
  try {
    const { message, history, currentTab } = req.body;
    const ai = getAiClient();
    const generateSmartSuggestions = (userText, aiText) => {
      const lower = (userText + " " + aiText).toLowerCase();
      if (lower.includes("\u0995\u09CB\u09B0\u09CD\u09B8") && (lower.includes("\u09B2\u09BF\u09B8\u09CD\u099F") || lower.includes("\u09AB\u09BF") || lower.includes("\u09AD\u09B0\u09CD\u09A4\u09BF") || lower.includes("\u098F\u09A8\u09B0\u09CB\u09B2"))) {
        return ["\u0995\u09CB\u09B0\u09CD\u09B8 \u09B8\u09BF\u09B2\u09C7\u09AC\u09BE\u09B8 \u0993 \u09B2\u09BE\u0987\u09AD \u0995\u09CD\u09B2\u09BE\u09B8 \u09AE\u09A1\u09BF\u0989\u09B2 \u{1F4DA}", "\u09AE\u09C7\u09A8\u09CD\u099F\u09B0 \u0993 \u099F\u09CD\u09B0\u09C7\u0987\u09A8\u09BE\u09B0\u09A6\u09C7\u09B0 \u09AA\u09CD\u09B0\u09CB\u09AB\u09BE\u0987\u09B2 \u{1F468}\u200D\u{1F3EB}", "\u09B8\u09BE\u09B0\u09CD\u099F\u09BF\u09AB\u09BF\u0995\u09C7\u099F \u0993 \u099C\u09AC \u09AA\u09CD\u09B2\u09C7\u09B8\u09AE\u09C7\u09A8\u09CD\u099F \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F \u{1F393}"];
      }
      if (lower.includes("\u0993\u09AF\u09BC\u09C7\u09AC") || lower.includes("\u09AA\u09CD\u09B0\u09CB\u0997\u09CD\u09B0\u09BE\u09AE\u09BF\u0982") || lower.includes("\u0995\u09CB\u09A1\u09BF\u0982") || lower.includes("developer") || lower.includes("\u09B6\u09BF\u0996")) {
        return ["\u09AB\u09C1\u09B2-\u09B8\u09CD\u099F\u09CD\u09AF\u09BE\u0995 \u09B2\u09BE\u09B0\u09CD\u09A8\u09BF\u0982 \u09B0\u09CB\u09A1\u09AE\u09CD\u09AF\u09BE\u09AA \u09E8\u09E6\u09E8\u09EC \u{1F680}", "\u09AB\u09CD\u09B0\u09A8\u09CD\u099F\u098F\u09A8\u09CD\u09A1 \u09AC\u09A8\u09BE\u09AE \u09AC\u09CD\u09AF\u09BE\u0995\u098F\u09A8\u09CD\u09A1 \u0995\u09CD\u09AF\u09BE\u09B0\u09BF\u09DF\u09BE\u09B0 \u0997\u09BE\u0987\u09A1 \u{1F4A1}", "\u09AA\u09CD\u09B0\u099C\u09C7\u0995\u09CD\u099F \u0986\u0987\u09A1\u09BF\u09DF\u09BE \u0993 \u09AA\u09CB\u09B0\u09CD\u099F\u09AB\u09CB\u09B2\u09BF\u0993 \u099F\u09BF\u09AA\u09B8 \u{1F6E0}\uFE0F"];
      }
      if (lower.includes("\u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09AA\u09CD\u09B2\u09C7\u09B8") || lower.includes("\u09AB\u09CD\u09B0\u09BF\u09B2\u09CD\u09AF\u09BE\u09A8\u09CD\u09B8") || lower.includes("\u0995\u09BE\u099C") || lower.includes("\u0987\u09A8\u0995\u09BE\u09AE")) {
        return ["\u09AA\u09CD\u09B0\u09A5\u09AE \u09AB\u09CD\u09B0\u09BF\u09B2\u09CD\u09AF\u09BE\u09A8\u09CD\u09B8 \u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u09AA\u09BE\u0993\u09DF\u09BE\u09B0 \u0995\u09CC\u09B6\u09B2 \u{1F4BC}", "\u0995\u09CD\u09B2\u09BE\u09AF\u09BC\u09C7\u09A8\u09CD\u099F \u09AA\u09CD\u09B0\u09AA\u09CB\u099C\u09BE\u09B2 \u09B2\u09C7\u0996\u09BE\u09B0 \u09A8\u09BF\u09DF\u09AE \u270D\uFE0F", "\u0995\u09AE\u09BF\u0989\u09A8\u09BF\u0995\u09C7\u09B6\u09A8 \u0993 \u09AA\u09CB\u09B0\u09CD\u099F\u09AB\u09CB\u09B2\u09BF\u0993 \u09B8\u09C7\u099F\u0986\u09AA \u{1F31F}"];
      }
      if (lower.includes("\u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8") || lower.includes("\u09AC\u09BF\u099C\u09A8\u09C7\u09B8") || lower.includes("\u09AC\u09CD\u09AF\u09AC\u09B8\u09BE") || lower.includes("\u0993\u09AF\u09BC\u09C7\u09AC\u09B8\u09BE\u0987\u099F \u09A4\u09C8\u09B0\u09BF")) {
        return ["\u09AC\u09CD\u09AF\u09AC\u09B8\u09BE\u09B0 \u099C\u09A8\u09CD\u09AF \u0986\u09A7\u09C1\u09A8\u09BF\u0995 \u0993\u09DF\u09C7\u09AC\u09B8\u09BE\u0987\u099F \u09A4\u09C8\u09B0\u09BF \u{1F310}", "\u09A1\u09BF\u099C\u09BF\u099F\u09BE\u09B2 \u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09BF\u0982 \u0993 \u09B2\u09BF\u09A1 \u099C\u09C7\u09A8\u09BE\u09B0\u09C7\u09B6\u09A8 \u{1F4C8}", "\u0986\u0987\u099F\u09BF \u09B8\u09AE\u09BE\u09A7\u09BE\u09A8 \u0993 \u09AC\u09BE\u099C\u09C7\u099F \u09AA\u09B0\u09BE\u09AE\u09B0\u09CD\u09B6 \u{1F4A1}"];
      }
      return ["\u0995\u09CD\u09AF\u09BE\u09B0\u09BF\u09DF\u09BE\u09B0 \u09AA\u09B0\u09BE\u09AE\u09B0\u09CD\u09B6 \u0993 \u0997\u09BE\u0987\u09A1\u09B2\u09BE\u0987\u09A8 \u{1F3AF}", "\u09AA\u09CD\u09B0\u09CB\u0997\u09CD\u09B0\u09BE\u09AE\u09BF\u0982 \u09AC\u09BE \u099F\u09C7\u0995\u09A8\u09BF\u0995\u09CD\u09AF\u09BE\u09B2 \u09AA\u09CD\u09B0\u09B6\u09CD\u09A8 \u{1F4BB}", "\u09B8\u09B0\u09BE\u09B8\u09B0\u09BF \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F \u09AA\u09CD\u09B0\u09A4\u09BF\u09A8\u09BF\u09A7\u09BF\u09B0 \u09B8\u09BE\u09B9\u09BE\u09AF\u09CD\u09AF \u{1F3A7}"];
    };
    if (!ai) {
      const defaultReply = `\u0986\u09B8\u09B8\u09BE\u09B2\u09BE\u09AE\u09C1 \u0986\u09B2\u09BE\u0987\u0995\u09C1\u09AE! \u0986\u09AE\u09BF \u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09CD\u09AE\u09BE\u09B0\u09CD\u099F \u098F\u0986\u0987 \u09B8\u09B9\u0995\u09BE\u09B0\u09C0 \u2728

\u0993\u09DF\u09C7\u09AC \u09A1\u09C7\u09AD\u09C7\u09B2\u09AA\u09AE\u09C7\u09A8\u09CD\u099F, \u09AA\u09CD\u09B0\u09CB\u0997\u09CD\u09B0\u09BE\u09AE\u09BF\u0982 \u09B0\u09CB\u09A1\u09AE\u09CD\u09AF\u09BE\u09AA, \u0995\u09CD\u09AF\u09BE\u09B0\u09BF\u09DF\u09BE\u09B0 \u0997\u09BE\u0987\u09A1\u09B2\u09BE\u0987\u09A8, \u09AA\u09CD\u09B0\u09AF\u09C1\u0995\u09CD\u09A4\u09BF\u0997\u09A4 \u09B8\u09AE\u09B8\u09CD\u09AF\u09BE \u09B8\u09AE\u09BE\u09A7\u09BE\u09A8 \u0995\u09BF\u0982\u09AC\u09BE \u09AC\u09CD\u09AF\u09AC\u09B8\u09BE \u09AC\u09C3\u09A6\u09CD\u09A7\u09BF \u09B8\u0982\u0995\u09CD\u09B0\u09BE\u09A8\u09CD\u09A4 \u09AF\u09C7\u0995\u09CB\u09A8\u09CB \u09AA\u09CD\u09B0\u09B6\u09CD\u09A8\u09C7\u09B0 \u09B8\u09A0\u09BF\u0995 \u09AA\u09B0\u09BE\u09AE\u09B0\u09CD\u09B6 \u09A6\u09BF\u09A4\u09C7 \u0986\u09AE\u09BF \u09AA\u09CD\u09B0\u09B8\u09CD\u09A4\u09C1\u09A4\u0964 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09CD\u09B0\u09B6\u09CD\u09A8\u099F\u09BF \u09B2\u09BF\u0996\u09C1\u09A8!`;
      return res.json({
        reply: defaultReply,
        suggestions: generateSmartSuggestions(message, defaultReply)
      });
    }
    const systemInstruction = `You are an intelligent, highly skilled, and professional AI Tech Consultant, Mentor & Assistant for the PTENit & Order Boss ecosystem.

CORE DIRECTIVE - RESPECT USER INTENT (CRITICAL):
1. ACCURATE ADVICE FIRST: When the user asks for advice, guidance, programming concepts, career roadmaps, bug fixing, learning paths, business strategies, or general tech questions:
   - Provide direct, thoughtful, accurate, structured, and actionable expert answers immediately.
   - Explain concepts clearly with practical steps, best practices, and logical advice.
2. ABSOLUTELY NO UNSOLICITED COURSE PROMOTION:
   - DO NOT automatically pitch, advertise, or force PTENit courses, fees, or institute admissions when the user is asking for general advice, tutorial help, learning tips, coding help, or suggestions.
   - ONLY discuss specific PTENit training courses if the user explicitly asks about available courses, training fees, or admission details at PTENit.
3. ABSOLUTELY NO UNSOLICITED SERVICE SELLING:
   - Provide helpful technical answers instead of blindly selling agency services, unless the user specifically asks to hire PTENit for a project.

STYLE & FORMATTING:
- Write in natural, polite, crystal clear Bengali (or English if the user writes in English).
- Tone: Helpful, knowledgeable, respectful, encouraging, and highly competent.
- STRICTLY DO NOT USE ASTERISKS FOR BOLDING (**text** or *text*). Always output clean, elegant plain text.
- Do not spam emojis. Keep the formatting clean with simple bullet points (\u2022 or -) where helpful.
- End your response with a line starting with "SUGGESTIONS:" followed by exactly 3 short, relevant options separated by "|". Example:
SUGGESTIONS: \u09B2\u09BE\u09B0\u09CD\u09A8\u09BF\u0982 \u09B0\u09CB\u09A1\u09AE\u09CD\u09AF\u09BE\u09AA|\u09AA\u09CD\u09B0\u09CD\u09AF\u09BE\u0995\u099F\u09BF\u09B8 \u09AA\u09CD\u09B0\u099C\u09C7\u0995\u09CD\u099F \u0986\u0987\u09A1\u09BF\u09DF\u09BE|\u0985\u09A8\u09CD\u09AF\u09BE\u09A8\u09CD\u09AF \u09AA\u09B0\u09BE\u09AE\u09B0\u09CD\u09B6`;
    const recentHistory = (history || []).slice(-6).map((h) => ({
      role: h.role === "user" ? "user" : "model",
      parts: [{ text: h.text }]
    }));
    const chatContents = [
      ...recentHistory,
      { role: "user", parts: [{ text: message }] }
    ];
    let response = null;
    try {
      response = await generateWithFallback(ai, chatContents, {
        systemInstruction,
        maxOutputTokens: 800,
        temperature: 0.7
      });
    } catch (apiErr) {
      console.warn("Gemini API call failed, using intelligent domain fallback engine:", apiErr?.message || apiErr);
      const lower = message.toLowerCase();
      let fallbackReply = `\u09A7\u09A8\u09CD\u09AF\u09AC\u09BE\u09A6 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09CD\u09B0\u09B6\u09CD\u09A8\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF! \u0986\u09AE\u09BF \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09B0\u09BE\u09AE\u09B0\u09CD\u09B6 \u0993 \u099F\u09C7\u0995\u09A8\u09BF\u0995\u09CD\u09AF\u09BE\u09B2 \u09AC\u09BF\u09B7\u09DF\u09C7 \u09B8\u09BE\u09B9\u09BE\u09AF\u09CD\u09AF \u0995\u09B0\u09A4\u09C7 \u09AA\u09CD\u09B0\u09B8\u09CD\u09A4\u09C1\u09A4\u0964 \u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09C1\u09A8\u09BF\u09B0\u09CD\u09A6\u09BF\u09B7\u09CD\u099F \u09B2\u0995\u09CD\u09B7\u09CD\u09AF \u09AC\u09BE \u09B8\u09AE\u09B8\u09CD\u09AF\u09BE\u099F\u09BF \u09AC\u09BF\u09B8\u09CD\u09A4\u09BE\u09B0\u09BF\u09A4 \u099C\u09BE\u09A8\u09BE\u09B2\u09C7 \u0986\u09AE\u09BF \u09A7\u09BE\u09AA\u09C7 \u09A7\u09BE\u09AA\u09C7 \u09A6\u09BF\u0995\u09A8\u09BF\u09B0\u09CD\u09A6\u09C7\u09B6\u09A8\u09BE \u09AA\u09CD\u09B0\u09A6\u09BE\u09A8 \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u0964`;
      if (lower.includes("\u0993\u09DF\u09C7\u09AC") || lower.includes("\u09B6\u09BF\u0996") || lower.includes("\u09AA\u09CD\u09B0\u09CB\u0997\u09CD\u09B0\u09BE\u09AE\u09BF\u0982") || lower.includes("\u0995\u09CB\u09A1\u09BF\u0982") || lower.includes("\u09B6\u09C1\u09B0\u09C1")) {
        fallbackReply = `\u0993\u09DF\u09C7\u09AC \u09A1\u09C7\u09AD\u09C7\u09B2\u09AA\u09AE\u09C7\u09A8\u09CD\u099F \u09B6\u09C7\u0996\u09BE\u09B0 \u0995\u09BE\u09B0\u09CD\u09AF\u0995\u09B0\u09C0 \u0997\u09BE\u0987\u09A1\u09B2\u09BE\u0987\u09A8:

\u09E7. \u09AC\u09C7\u09B8\u09BF\u0995 \u09AB\u09BE\u09A8\u09CD\u09A1\u09BE\u09AE\u09C7\u09A8\u09CD\u099F\u09BE\u09B2: \u09AA\u09CD\u09B0\u09A5\u09AE\u09C7 HTML5, CSS3 \u0993 \u09B0\u09C7\u09B8\u09AA\u09A8\u09B8\u09BF\u09AD \u09A1\u09BF\u099C\u09BE\u0987\u09A8 (Flexbox/Grid/Tailwind) \u09AD\u09BE\u09B2\u09CB \u0995\u09B0\u09C7 \u0986\u09DF\u09A4\u09CD\u09A4 \u0995\u09B0\u09C1\u09A8\u0964
\u09E8. \u09AA\u09CD\u09B0\u09CB\u0997\u09CD\u09B0\u09BE\u09AE\u09BF\u0982 \u09B2\u099C\u09BF\u0995: JavaScript (ES6+, DOM, Fetch API, Async/Await) \u09A6\u09BF\u09DF\u09C7 \u099B\u09CB\u099F \u099B\u09CB\u099F \u0987\u09A8\u09CD\u099F\u09BE\u09B0\u09C7\u0995\u09CD\u099F\u09BF\u09AD \u09AA\u09CD\u09B0\u099C\u09C7\u0995\u09CD\u099F \u09A4\u09C8\u09B0\u09BF \u0995\u09B0\u09C1\u09A8\u0964
\u09E9. \u09AB\u09CD\u09B0\u09A8\u09CD\u099F\u098F\u09A8\u09CD\u09A1 \u09AB\u09CD\u09B0\u09C7\u09AE\u0993\u09DF\u09BE\u09B0\u09CD\u0995: React.js \u09AC\u09BE Next.js \u09B6\u09BF\u0996\u09C7 \u0995\u09AE\u09CD\u09AA\u09CB\u09A8\u09C7\u09A8\u09CD\u099F-\u09AC\u09C7\u09B8\u09A1 \u0986\u09B0\u09CD\u0995\u09BF\u099F\u09C7\u0995\u099A\u09BE\u09B0 \u0986\u09DF\u09A4\u09CD\u09A4 \u0995\u09B0\u09C1\u09A8\u0964
\u09EA. \u09AC\u09CD\u09AF\u09BE\u0995\u098F\u09A8\u09CD\u09A1 \u0993 \u09A1\u09C7\u099F\u09BE\u09AC\u09C7\u09B8: Node.js/Express \u098F\u09AC\u0982 MongoDB \u09AC\u09BE PostgreSQL \u09B6\u09BF\u0996\u09C1\u09A8\u0964
\u09EB. \u09A8\u09BF\u09DF\u09AE\u09BF\u09A4 \u09AA\u09CD\u09B0\u09CD\u09AF\u09BE\u0995\u099F\u09BF\u09B8: \u09AA\u09CD\u09B0\u09A4\u09BF\u09A6\u09BF\u09A8 \u0995\u09CB\u09A1 \u09B2\u09BF\u0996\u09C1\u09A8 \u098F\u09AC\u0982 \u0997\u09BF\u099F\u09B9\u09BE\u09AC\u09C7 \u09AA\u09CD\u09B0\u099C\u09C7\u0995\u09CD\u099F \u09AA\u09C1\u09B6 \u0995\u09B0\u09C7 \u09AC\u09BE\u09B8\u09CD\u09A4\u09AC \u09AA\u09CB\u09B0\u09CD\u099F\u09AB\u09CB\u09B2\u09BF\u0993 \u09A4\u09C8\u09B0\u09BF \u0995\u09B0\u09C1\u09A8\u0964`;
      } else if (lower.includes("\u09AB\u09CD\u09B0\u09BF\u09B2\u09CD\u09AF\u09BE\u09A8\u09CD\u09B8") || lower.includes("\u0987\u09A8\u0995\u09BE\u09AE") || lower.includes("\u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09AA\u09CD\u09B2\u09C7\u09B8") || lower.includes("\u0995\u09BE\u099C")) {
        fallbackReply = `\u09AB\u09CD\u09B0\u09BF\u09B2\u09CD\u09AF\u09BE\u09A8\u09CD\u09B8\u09BF\u0982 \u09B6\u09C1\u09B0\u09C1 \u0995\u09B0\u09BE\u09B0 \u09AC\u09BE\u09B8\u09CD\u09A4\u09AC\u09B8\u09AE\u09CD\u09AE\u09A4 \u09AA\u09B0\u09BE\u09AE\u09B0\u09CD\u09B6:

\u09E7. \u09AF\u09C7\u0995\u09CB\u09A8\u09CB \u098F\u0995\u099F\u09BF \u09B8\u09C1\u09A8\u09BF\u09B0\u09CD\u09A6\u09BF\u09B7\u09CD\u099F \u09B8\u09CD\u0995\u09BF\u09B2 \u09AC\u09BE\u099B\u09BE\u0987 \u0995\u09B0\u09C1\u09A8 (\u09AF\u09C7\u09AE\u09A8: \u09AB\u09CD\u09B0\u09A8\u09CD\u099F\u098F\u09A8\u09CD\u09A1 \u09A1\u09C7\u09AD\u09C7\u09B2\u09AA\u09AE\u09C7\u09A8\u09CD\u099F, \u0993\u09AF\u09BC\u09BE\u09B0\u09CD\u09A1\u09AA\u09CD\u09B0\u09C7\u09B8 \u09AC\u09BE \u0987\u0989\u0986\u0987/\u0987\u0989\u098F\u0995\u09CD\u09B8 \u09A1\u09BF\u099C\u09BE\u0987\u09A8)\u0964
\u09E8. \u0995\u09CD\u09B2\u09BE\u09DF\u09C7\u09A8\u09CD\u099F\u0995\u09C7 \u09A6\u09C7\u0996\u09BE\u09A8\u09CB\u09B0 \u09AE\u09A4\u09CB \u09E9-\u09EB\u099F\u09BF \u09AA\u09C2\u09B0\u09CD\u09A3\u09BE\u0999\u09CD\u0997 \u0993 \u09B2\u09BE\u0987\u09AD \u09AA\u09CD\u09B0\u099C\u09C7\u0995\u09CD\u099F\u09C7\u09B0 \u09AA\u09CB\u09B0\u09CD\u099F\u09AB\u09CB\u09B2\u09BF\u0993 \u09A4\u09C8\u09B0\u09BF \u0995\u09B0\u09C1\u09A8\u0964
\u09E9. \u09AC\u09BE\u09DF\u09BE\u09B0 \u09B0\u09BF\u0995\u09CB\u09DF\u09BE\u09B0\u09AE\u09C7\u09A8\u09CD\u099F \u09A8\u09BF\u0996\u09C1\u0981\u09A4\u09AD\u09BE\u09AC\u09C7 \u09AC\u09C1\u099D\u09C7 \u09AA\u09BE\u09B0\u09B8\u09CB\u09A8\u09BE\u09B2\u09BE\u0987\u099C\u09A1 \u09AA\u09CD\u09B0\u09AA\u09CB\u099C\u09BE\u09B2 \u09B2\u09C7\u0996\u09BE\u09B0 \u0985\u09AD\u09CD\u09AF\u09BE\u09B8 \u0995\u09B0\u09C1\u09A8\u0964
\u09EA. \u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09AA\u09CD\u09B2\u09C7\u09B8\u09C7 \u09AD\u09BE\u09B2\u09CB \u09B0\u09BF\u09AD\u09BF\u0989 \u09AC\u099C\u09BE\u09DF \u09B0\u09BE\u0996\u09A4\u09C7 \u09B8\u09AE\u09DF\u09AE\u09A4\u09CB \u09A1\u09C7\u09B2\u09BF\u09AD\u09BE\u09B0\u09BF \u0993 \u099A\u09AE\u09CE\u0995\u09BE\u09B0 \u0995\u09AE\u09BF\u0989\u09A8\u09BF\u0995\u09C7\u09B6\u09A8 \u09A6\u09BF\u09A8\u0964`;
      } else if (lower.includes("\u09AC\u09CD\u09AF\u09AC\u09B8\u09BE") || lower.includes("\u09AC\u09BF\u099C\u09A8\u09C7\u09B8") || lower.includes("\u09B8\u09C7\u09B2") || lower.includes("\u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09BF\u0982")) {
        fallbackReply = `\u0985\u09A8\u09B2\u09BE\u0987\u09A8 \u09AC\u09CD\u09AF\u09AC\u09B8\u09BE \u0993 \u09B2\u09BF\u09A1 \u09AC\u09C3\u09A6\u09CD\u09A7\u09BF\u09B0 \u0995\u09BE\u09B0\u09CD\u09AF\u0995\u09B0 \u0995\u09CC\u09B6\u09B2:

\u09E7. \u099F\u09BE\u09B0\u09CD\u0997\u09C7\u099F\u09C7\u09A1 \u0985\u09A1\u09BF\u09DF\u09C7\u09A8\u09CD\u09B8 \u09B0\u09BF\u09B8\u09BE\u09B0\u09CD\u099A: \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09A3\u09CD\u09AF \u09AC\u09BE \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8\u09C7\u09B0 \u09AA\u09CD\u09B0\u0995\u09C3\u09A4 \u0995\u09CD\u09B0\u09C7\u09A4\u09BE \u0995\u09BE\u09B0\u09BE \u09A4\u09BE \u09A8\u09BF\u09B0\u09CD\u09A7\u09BE\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8\u0964
\u09E8. \u09A8\u09BF\u09B0\u09CD\u09AD\u09B0\u09AF\u09CB\u0997\u09CD\u09AF \u09A1\u09BF\u099C\u09BF\u099F\u09BE\u09B2 \u09AA\u09CD\u09B0\u09C7\u099C\u09C7\u09A8\u09CD\u09B8: \u09AA\u09CD\u09B0\u09AB\u09C7\u09B6\u09A8\u09BE\u09B2 \u0993 \u09AB\u09BE\u09B8\u09CD\u099F-\u09B2\u09CB\u09A1\u09BF\u0982 \u0993\u09DF\u09C7\u09AC\u09B8\u09BE\u0987\u099F \u09B0\u09BE\u0996\u09C1\u09A8 \u09AF\u09BE \u09AE\u09CB\u09AC\u09BE\u0987\u09B2 \u09AC\u09BE\u09A8\u09CD\u09A7\u09AC\u0964
\u09E9. \u09AD\u09CD\u09AF\u09BE\u09B2\u09C1-\u09AD\u09BF\u09A4\u09CD\u09A4\u09BF\u0995 \u0995\u09A8\u099F\u09C7\u09A8\u09CD\u099F: \u09B8\u09CB\u09B6\u09CD\u09AF\u09BE\u09B2 \u09AE\u09BF\u09A1\u09BF\u09DF\u09BE\u09DF \u0997\u09CD\u09B0\u09BE\u09B9\u0995\u09C7\u09B0 \u09B8\u09AE\u09B8\u09CD\u09AF\u09BE\u09B0 \u09B8\u09AE\u09BE\u09A7\u09BE\u09A8\u09AE\u09C2\u09B2\u0995 \u0995\u09A8\u099F\u09C7\u09A8\u09CD\u099F \u0993 \u0995\u09BE\u09B8\u09CD\u099F\u09AE\u09BE\u09B0 \u09B0\u09BF\u09AD\u09BF\u0989 \u09AA\u09CD\u09B0\u0995\u09BE\u09B6 \u0995\u09B0\u09C1\u09A8\u0964
\u09EA. \u0995\u09A8\u09AD\u09BE\u09B0\u09CD\u09B8\u09A8 \u099F\u09CD\u09B0\u09CD\u09AF\u09BE\u0995\u09BF\u0982: \u09AB\u09C7\u09B8\u09AC\u09C1\u0995 \u09AA\u09BF\u0995\u09CD\u09B8\u09C7\u09B2 \u0993 \u0997\u09C1\u0997\u09B2 \u0985\u09CD\u09AF\u09BE\u09A8\u09BE\u09B2\u09BF\u099F\u09BF\u0995\u09CD\u09B8 \u09A6\u09BF\u09DF\u09C7 \u0995\u09CD\u09AF\u09BE\u09AE\u09CD\u09AA\u09C7\u0987\u09A8 \u0985\u09AA\u09CD\u099F\u09BF\u09AE\u09BE\u0987\u099C \u0995\u09B0\u09C1\u09A8\u0964`;
      }
      return res.json({
        reply: fallbackReply,
        suggestions: generateSmartSuggestions(message, fallbackReply)
      });
    }
    let rawText = response.text || "\u09A7\u09A8\u09CD\u09AF\u09AC\u09BE\u09A6! PTENit \u0993 Order Boss \u098F\u0986\u0987 \u09B8\u09B9\u0995\u09BE\u09B0\u09C0 \u09B8\u09BE\u09B9\u09BE\u09AF\u09CD\u09AF \u0995\u09B0\u09A4\u09C7 \u09AA\u09CD\u09B0\u09B8\u09CD\u09A4\u09C1\u09A4\u0964";
    let suggestions = [];
    if (rawText.includes("SUGGESTIONS:")) {
      const parts = rawText.split("SUGGESTIONS:");
      rawText = parts[0].trim();
      const suggStr = parts[1].trim();
      suggestions = suggStr.split("|").map((s) => s.trim()).filter(Boolean).slice(0, 3);
    }
    rawText = rawText.replace(/\*\*/g, "");
    if (suggestions.length === 0) {
      suggestions = generateSmartSuggestions(message, rawText);
    }
    return res.json({
      reply: rawText,
      suggestions
    });
  } catch (err) {
    console.error("Gemini Chat error:", err);
    return res.json({
      reply: "PTENit \u0993 Order Boss \u098F\u0986\u0987 \u09B8\u09B9\u0995\u09BE\u09B0\u09C0 \u09B8\u0982\u09AF\u09CB\u0997\u09C7 \u09B8\u09BE\u09AE\u09DF\u09BF\u0995 \u09B8\u09AE\u09B8\u09CD\u09AF\u09BE \u09B9\u09DF\u09C7\u099B\u09C7\u0964 \u0985\u09A8\u09C1\u0997\u09CD\u09B0\u09B9 \u0995\u09B0\u09C7 \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8\u0964",
      suggestions: ["\u09B2\u09BE\u0987\u09AD \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F \u099F\u09BF\u09AE\u09C7\u09B0 \u09B8\u09BE\u09A5\u09C7 \u0995\u09A5\u09BE \u09AC\u09B2\u09C1\u09A8 \u{1F3A7}", "\u098F\u09A1\u09AE\u09BF\u09A8 \u09AA\u09CD\u09AF\u09BE\u09A8\u09C7\u09B2\u09C7 \u09AA\u09CD\u09B0\u09AC\u09C7\u09B6 \u0995\u09B0\u09C1\u09A8 \u{1F6E1}\uFE0F", "\u0993\u09DF\u09C7\u09AC\u09B8\u09BE\u0987\u099F\u09C7 \u09AB\u09BF\u09B0\u09C7 \u09AF\u09BE\u09A8 \u{1F3E0}"]
    });
  }
});
app.post("/api/gemini/copilot-action", async (req, res) => {
  try {
    const { query, history, currentTab } = req.body;
    const ai = getAiClient();
    const cleanQuery = (query || "").trim();
    if (!cleanQuery) {
      return res.json({
        reply: "\u0986\u09AE\u09BF \u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09BE\u09B0\u09CD\u09AC\u09BF\u0995 \u09B8\u09B9\u09BE\u09DF\u09A4\u09BE\u09DF \u09AA\u09CD\u09B0\u09B8\u09CD\u09A4\u09C1\u09A4\u0964 \u0995\u09CB\u09B0\u09CD\u09B8, \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8, \u09AB\u09CD\u09B0\u09BF \u0995\u09CD\u09B2\u09BE\u09B8, \u09AB\u09CD\u09B0\u09BF\u09B2\u09CD\u09AF\u09BE\u09A8\u09CD\u09B8\u09BF\u0982 \u09AC\u09BE \u09AF\u09C7\u0995\u09CB\u09A8\u09CB \u09AA\u09CD\u09B0\u09B6\u09CD\u09A8 \u09B2\u09BF\u0996\u09C1\u09A8!",
        actionType: "general",
        suggestions: ["\u09E7\u09E6\u09E6% \u09AB\u09CD\u09B0\u09BF \u0995\u09CB\u09B0\u09CD\u09B8\u09B8\u09AE\u09C2\u09B9 \u{1F393}", "\u0993\u09AF\u09BC\u09C7\u09AC \u09A1\u09C7\u09AD\u09C7\u09B2\u09AA\u09AE\u09C7\u09A8\u09CD\u099F \u0995\u09CB\u09B0\u09CD\u09B8 \u{1F4BB}", "\u09A1\u09BF\u099C\u09BF\u099F\u09BE\u09B2 \u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09BF\u0982 \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8 \u{1F4C8}", "\u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F\u09C7 \u0995\u09A5\u09BE \u09AC\u09B2\u09C1\u09A8 \u{1F3A7}"]
      });
    }
    if (!ai) {
      const lower = cleanQuery.toLowerCase();
      let actionType = "general";
      let reply = "\u0986\u09AE\u09BF \u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09B9\u09BE\u09DF\u09A4\u09BE\u09DF \u09AA\u09CD\u09B0\u09B8\u09CD\u09A4\u09C1\u09A4\u0964 \u09A8\u09BF\u099A\u09C7\u09B0 \u0985\u09AA\u09B6\u09A8\u0997\u09C1\u09B2\u09CB \u09A5\u09C7\u0995\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09CD\u09B0\u09DF\u09CB\u099C\u09A8\u09C0\u09DF \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8 \u09AC\u09BE \u0995\u09CB\u09B0\u09CD\u09B8 \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8:";
      let suggestions = ["\u09AB\u09CD\u09B0\u09BF \u0995\u09CB\u09B0\u09CD\u09B8\u09B8\u09AE\u09C2\u09B9 \u09A6\u09C7\u0996\u09C1\u09A8 \u{1F393}", "\u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8 \u09AA\u09CD\u09AF\u09BE\u0995\u09C7\u099C \u{1F4BC}", "\u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09AA\u09CD\u09B2\u09C7\u09B8 \u0997\u09BF\u0997 \u26A1", "\u09B9\u09C7\u09B2\u09CD\u09AA\u09B2\u09BE\u0987\u09A8 \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F \u{1F3A7}"];
      if (lower.includes("\u09AB\u09CD\u09B0\u09BF") || lower.includes("free") || lower.includes("\u09AC\u09BF\u09A8\u09BE\u09AE\u09C2\u09B2\u09CD\u09AF\u09C7") || lower.includes("\u099F\u09BE\u0995\u09BE \u099B\u09BE\u09DC\u09BE")) {
        actionType = "free_courses";
        reply = "\u0986\u09AA\u09A8\u09BE\u09B0 \u099C\u09A8\u09CD\u09AF \u09AA\u09CD\u09B2\u09CD\u09AF\u09BE\u099F\u09AB\u09B0\u09CD\u09AE\u09C7\u09B0 \u09E7\u09E6\u09E6% \u09AB\u09CD\u09B0\u09BF \u0993 \u0993\u09AA\u09C7\u09A8 \u0995\u09CB\u09B0\u09CD\u09B8\u09B8\u09AE\u09C2\u09B9 \u09A8\u09BF\u099A\u09C7 \u09A8\u09BF\u09DF\u09C7 \u0986\u09B8\u09BE \u09B9\u09DF\u09C7\u099B\u09C7! \u0986\u09AA\u09A8\u09BF \u09B8\u09B0\u09BE\u09B8\u09B0\u09BF \u09E7-\u0995\u09CD\u09B2\u09BF\u0995 \u0995\u09B0\u09C7\u0987 \u098F\u09A8\u09B0\u09CB\u09B2 \u0995\u09B0\u09C7 \u098F\u0996\u09A8\u0987 \u0995\u09CD\u09B2\u09BE\u09B8 \u09B6\u09C1\u09B0\u09C1 \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8:";
        suggestions = ["\u09AB\u09C7\u09B8\u09AC\u09C1\u0995 \u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09BF\u0982 \u09AB\u09CD\u09B0\u09BF \u0995\u09CB\u09B0\u09CD\u09B8 \u{1F4F1}", "\u0995\u09CD\u09AF\u09BE\u09A8\u09AD\u09BE \u09A1\u09BF\u099C\u09BE\u0987\u09A8 \u09AB\u09CD\u09B0\u09BF \u0995\u09CD\u09B0\u09CD\u09AF\u09BE\u09B6 \u0995\u09CB\u09B0\u09CD\u09B8 \u{1F3A8}", "\u0993\u09AF\u09BC\u09C7\u09AC \u09A1\u09C7\u09AD\u09C7\u09B2\u09AA\u09AE\u09C7\u09A8\u09CD\u099F \u09B8\u09CD\u099F\u09BE\u09B0\u09CD\u099F\u09BE\u09B0 \u{1F680}"];
      } else if (lower.includes("\u0995\u09CB\u09B0\u09CD\u09B8") || lower.includes("\u09B6\u09BF\u0996") || lower.includes("admission") || lower.includes("\u09AD\u09B0\u09CD\u09A4\u09BF")) {
        actionType = "courses";
        reply = "\u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u099B\u09A8\u09CD\u09A6\u09C7\u09B0 \u09B8\u09C7\u09B0\u09BE \u0995\u09CB\u09B0\u09CD\u09B8\u09B8\u09AE\u09C2\u09B9 \u09A8\u09BF\u099A\u09C7 \u09B8\u09BE\u099C\u09BF\u09DF\u09C7 \u09A6\u09C7\u0993\u09DF\u09BE \u09B9\u09B2\u09CB:";
        suggestions = ["\u0993\u09AF\u09BC\u09C7\u09AC \u09A1\u09C7\u09AD\u09C7\u09B2\u09AA\u09AE\u09C7\u09A8\u09CD\u099F \u{1F4BB}", "\u0987\u0989\u099F\u09BF\u0989\u09AC \u098F\u09B8\u0987\u0993 \u{1F50D}", "\u0993\u09AF\u09BC\u09BE\u09B0\u09CD\u09A1\u09AA\u09CD\u09B0\u09C7\u09B8 \u0993 \u0987-\u0995\u09AE\u09BE\u09B0\u09CD\u09B8 \u{1F310}"];
      } else if (lower.includes("\u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8") || lower.includes("\u09AC\u09BE\u09A8\u09BE") || lower.includes("\u09A4\u09C8\u09B0\u09BF") || lower.includes("service")) {
        actionType = "services";
        reply = "PTENit \u098F\u099C\u09C7\u09A8\u09CD\u09B8\u09BF\u09B0 \u09AA\u09CD\u09B0\u09AB\u09C7\u09B6\u09A8\u09BE\u09B2 \u0986\u0987\u099F\u09BF \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8\u09C7\u09B8 \u0993 \u09AA\u09CD\u09AF\u09BE\u0995\u09C7\u099C\u09B8\u09AE\u09C2\u09B9 \u09A8\u09BF\u099A\u09C7 \u09A6\u09C7\u0993\u09DF\u09BE \u09B9\u09B2\u09CB:";
        suggestions = ["\u0993\u09AF\u09BC\u09C7\u09AC\u09B8\u09BE\u0987\u099F \u09A4\u09C8\u09B0\u09BF \u{1F310}", "\u09A1\u09BF\u099C\u09BF\u099F\u09BE\u09B2 \u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09BF\u0982 \u{1F4C8}", "\u098F\u09B8\u0987\u0993 \u09B0\u200D\u09CD\u09AF\u09BE\u0982\u0995\u09BF\u0982 \u{1F50D}"];
      } else if (lower.includes("\u0997\u09BF\u0997") || lower.includes("\u09AB\u09CD\u09B0\u09BF\u09B2\u09CD\u09AF\u09BE\u09A8\u09CD\u09B8") || lower.includes("gig") || lower.includes("specialist")) {
        actionType = "gigs";
        reply = "\u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09AA\u09CD\u09B2\u09C7\u09B8\u09C7\u09B0 \u099F\u09AA \u09B0\u09C7\u099F\u09C7\u09A1 \u09B8\u09CD\u09AA\u09C7\u09B6\u09BE\u09B2\u09BF\u09B8\u09CD\u099F\u09A6\u09C7\u09B0 \u099C\u09A8\u09AA\u09CD\u09B0\u09BF\u09DF \u0997\u09BF\u0997\u0997\u09C1\u09B2\u09CB \u09A8\u09BF\u099A\u09C7 \u09A6\u09C7\u0996\u09C1\u09A8:";
        suggestions = ["\u09B2\u09CB\u0997\u09CB \u09A1\u09BF\u099C\u09BE\u0987\u09A8 \u0997\u09BF\u0997 \u{1F3A8}", "\u09AB\u09C1\u09B2-\u09B8\u09CD\u099F\u09CD\u09AF\u09BE\u0995 \u0993\u09AF\u09BC\u09C7\u09AC \u0997\u09BF\u0997 \u{1F4BB}", "\u09AD\u09BF\u09A1\u09BF\u0993 \u098F\u09A1\u09BF\u099F\u09BF\u0982 \u0997\u09BF\u0997 \u{1F3AC}"];
      } else if (lower.includes("\u09B2\u0997\u0987\u09A8") || lower.includes("\u0985\u09CD\u09AF\u09BE\u0995\u09BE\u0989\u09A8\u09CD\u099F") || lower.includes("\u09B8\u09BE\u0987\u09A8 \u0986\u09AA") || lower.includes("login")) {
        actionType = "auth";
        reply = "\u0986\u09AA\u09A8\u09BE\u09B0 \u098F\u0995\u09BE\u0989\u09A8\u09CD\u099F\u09C7 \u09AA\u09CD\u09B0\u09AC\u09C7\u09B6 \u0995\u09B0\u09A4\u09C7 \u0985\u09A5\u09AC\u09BE \u09A8\u09A4\u09C1\u09A8 \u0985\u09CD\u09AF\u09BE\u0995\u09BE\u0989\u09A8\u09CD\u099F \u09A4\u09C8\u09B0\u09BF \u0995\u09B0\u09A4\u09C7 \u09A8\u09BF\u099A\u09C7\u09B0 \u09AC\u09BE\u099F\u09A8\u09C7 \u099A\u09BE\u09AA \u09A6\u09BF\u09A8:";
        suggestions = ["\u09B2\u0997\u0987\u09A8 \u0989\u0987\u09A8\u09CD\u09A1\u09CB \u0996\u09C1\u09B2\u09C1\u09A8 \u{1F510}", "\u09A1\u09C7\u09AE\u09CB \u09B8\u09CD\u099F\u09C1\u09A1\u09C7\u09A8\u09CD\u099F \u09B2\u0997\u0987\u09A8 \u{1F393}", "\u09A1\u09C7\u09AE\u09CB \u098F\u09A1\u09AE\u09BF\u09A8 \u09B2\u0997\u0987\u09A8 \u{1F6E1}\uFE0F"];
      } else if (lower.includes("\u09AA\u09C7\u09AE\u09C7\u09A8\u09CD\u099F") || lower.includes("\u09AC\u09BF\u0995\u09BE\u09B6") || lower.includes("\u09A8\u0997\u09A6") || lower.includes("\u09A8\u09AE\u09CD\u09AC\u09B0") || lower.includes("payment")) {
        actionType = "payment";
        reply = "PTENit \u0993 Order Boss \u0985\u09AB\u09BF\u09B8\u09BF\u09DF\u09BE\u09B2 \u09AA\u09C7\u09AE\u09C7\u09A8\u09CD\u099F \u09AE\u09C7\u09A5\u09A1 \u0993 \u09AE\u09BE\u09B0\u09CD\u099A\u09C7\u09A8\u09CD\u099F \u09A8\u09AE\u09CD\u09AC\u09B0:\n\u2022 \u09AC\u09BF\u0995\u09BE\u09B6 (Personal): 01700-000000\n\u2022 \u09A8\u0997\u09A6 (Personal): 01800-000000\n\u2022 \u09B0\u0995\u09C7\u099F: 01900-000000\n\u2022 \u09AC\u09CD\u09AF\u09BE\u0982\u0995: DBBL / City Bank\n\n\u09AA\u09C7\u09AE\u09C7\u09A8\u09CD\u099F \u09B8\u09AE\u09CD\u09AA\u09A8\u09CD\u09A8 \u0995\u09B0\u09C7 TrxID \u09A6\u09BF\u09DF\u09C7 \u09AF\u09C7\u0995\u09CB\u09A8\u09CB \u0995\u09CB\u09B0\u09CD\u09B8 \u09AC\u09BE \u09B8\u09BE\u09B0\u09CD\u09AD\u09BF\u09B8 \u0995\u09A8\u09AB\u09BE\u09B0\u09CD\u09AE \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964";
        suggestions = ["\u09AA\u09C7\u09AE\u09C7\u09A8\u09CD\u099F \u09A8\u09AE\u09CD\u09AC\u09B0 \u0995\u09AA\u09BF \u0995\u09B0\u09C1\u09A8 \u{1F4CB}", "\u0995\u09CB\u09B0\u09CD\u09B8\u09C7 \u09AD\u09B0\u09CD\u09A4\u09BF \u09B9\u09A8 \u{1F393}", "\u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F\u09C7 \u0995\u09A5\u09BE \u09AC\u09B2\u09C1\u09A8 \u{1F3A7}"];
      }
      return res.json({
        reply,
        actionType,
        suggestions
      });
    }
    const systemPrompt = `You are PTENit & Order Boss Super AI Copilot (\u09B8\u09C1\u09AA\u09BE\u09B0 \u098F\u0986\u0987 \u09B8\u09B9\u0995\u09BE\u09B0\u09C0 \u0993 \u0985\u09CD\u09AF\u09BE\u0995\u09B6\u09A8 \u09B9\u09BE\u09AC).
The user is asking a question or requesting an action on the PTENit platform.

YOUR RESPONSIBILITY:
Understand the user's intent and return a clean JSON response with:
1. "reply": A friendly, helpful, short response in clear Bengali (or English if prompted in English). NO ASTERISKS (**text**).
2. "actionType": One of:
   - "free_courses": When user asks for free courses, gratis learning, "\u09AB\u09CD\u09B0\u09BF \u0995\u09CB\u09B0\u09CD\u09B8", "\u09AC\u09BF\u09A8\u09BE\u09AE\u09C2\u09B2\u09CD\u09AF\u09C7 \u09B6\u09BF\u0996\u09AC", etc.
   - "courses": When user asks for specific courses, training, learning roadmap, etc.
   - "services": When user wants to hire IT services, agency website design, marketing, SEO, etc.
   - "gigs": When user asks for marketplace freelance gigs, top specialists, etc.
   - "digital_products": When user asks for software, scripts, templates, etc.
   - "auth": When user asks to login, register, sign up, or switch accounts.
   - "payment": When user asks for bKash/Nagad payment numbers, fees, methods.
   - "support": When user asks for helpline, WhatsApp, live chat, or talk to mentor.
   - "general": For coding help, explanations, general questions.
3. "categoryFilter": optional string if query mentions a specific category (e.g. 'Development', 'Design', 'Marketing', 'SEO').
4. "suggestions": array of 3-4 short Bengali chips.

Example user query: "\u0986\u09AE\u09BE\u0995\u09C7 \u09AB\u09CD\u09B0\u09BF \u0995\u09CB\u09B0\u09CD\u09B8 \u09A6\u09BE\u0993"
Response:
{
  "reply": "\u0986\u09AA\u09A8\u09BE\u09B0 \u099C\u09A8\u09CD\u09AF \u09AA\u09CD\u09B2\u09CD\u09AF\u09BE\u099F\u09AB\u09B0\u09CD\u09AE\u09C7\u09B0 \u09E7\u09E6\u09E6% \u09AB\u09CD\u09B0\u09BF \u0995\u09CB\u09B0\u09CD\u09B8\u09B8\u09AE\u09C2\u09B9 \u09A8\u09BF\u099A\u09C7 \u09A8\u09BF\u09DF\u09C7 \u0986\u09B8\u09BE \u09B9\u09DF\u09C7\u099B\u09C7! \u09B8\u09B0\u09BE\u09B8\u09B0\u09BF \u09E7-\u0995\u09CD\u09B2\u09BF\u0995\u09C7\u0987 \u0995\u09CD\u09B2\u09BE\u09B8\u09C7 \u09AF\u09C1\u0995\u09CD\u09A4 \u09B9\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8:",
  "actionType": "free_courses",
  "categoryFilter": "",
  "suggestions": ["\u09AB\u09C7\u09B8\u09AC\u09C1\u0995 \u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09BF\u0982 \u09AB\u09CD\u09B0\u09BF \u0995\u09CB\u09B0\u09CD\u09B8", "\u0995\u09CD\u09AF\u09BE\u09A8\u09AD\u09BE \u09A1\u09BF\u099C\u09BE\u0987\u09A8 \u09AB\u09CD\u09B0\u09BF \u0995\u09CD\u09B0\u09CD\u09AF\u09BE\u09B6 \u0995\u09CB\u09B0\u09CD\u09B8", "\u0993\u09AF\u09BC\u09C7\u09AC \u09B8\u09CD\u099F\u09BE\u09B0\u09CD\u099F\u09BE\u09B0 \u0995\u09CB\u09B0\u09CD\u09B8"]
}`;
    const response = await generateWithFallback(ai, cleanQuery, {
      systemInstruction: systemPrompt,
      responseMimeType: "application/json",
      temperature: 0.6
    });
    const parsed = JSON.parse(response.text || "{}");
    if (parsed.reply) {
      parsed.reply = parsed.reply.replace(/\*\*/g, "");
    }
    return res.json(parsed);
  } catch (err) {
    console.error("Gemini Copilot Action error:", err);
    return res.json({
      reply: "\u0986\u09AE\u09BF \u0986\u09AA\u09A8\u09BE\u09B0 \u09B8\u09B9\u09BE\u09DF\u09A4\u09BE\u09DF \u09AA\u09CD\u09B0\u09B8\u09CD\u09A4\u09C1\u09A4\u0964 \u09A8\u09BF\u099A\u09C7 \u09A5\u09C7\u0995\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09CD\u09B0\u09DF\u09CB\u099C\u09A8\u09C0\u09DF \u0985\u09AA\u09B6\u09A8 \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8:",
      actionType: "general",
      suggestions: ["\u09E7\u09E6\u09E6% \u09AB\u09CD\u09B0\u09BF \u0995\u09CB\u09B0\u09CD\u09B8 \u{1F393}", "\u0993\u09AF\u09BC\u09C7\u09AC \u09A1\u09C7\u09AD\u09C7\u09B2\u09AA\u09AE\u09C7\u09A8\u09CD\u099F \u{1F4BB}", "\u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F\u09AA\u09CD\u09B2\u09C7\u09B8 \u0997\u09BF\u0997 \u26A1", "\u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F \u{1F3A7}"]
    });
  }
});
app.post("/api/portfolio/import", async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ error: "Portfolio URL is required" });
    }
    let platform = "Portfolio Website";
    if (url.includes("behance.net")) platform = "Behance";
    else if (url.includes("github.com")) platform = "GitHub";
    else if (url.includes("linkedin.com")) platform = "LinkedIn";
    else if (url.includes("dribbble.com")) platform = "Dribbble";
    return res.json({
      success: true,
      platform,
      extractedName: "Verified Order Boss Freelancer",
      extractedTitle: `Senior Designer & Full-Stack Pro (${platform} Verified)`,
      extractedBio: `Professional creator imported directly from ${platform}. Over 50+ successful projects completed with exceptional quality and 5-star client ratings. Dedicated to delivering top-tier work on Order Boss.`,
      extractedSkills: ["React & Next.js", "UI/UX Design", "TypeScript", "Node.js Backend", "Tailwind CSS", "AI Agent Integration"],
      extractedGalleries: [
        "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80"
      ]
    });
  } catch (err) {
    return res.status(500).json({ error: "Failed to parse portfolio URL" });
  }
});
app.post("/api/payment/test-connection", async (req, res) => {
  try {
    const { gateway, storeId, storePassword, appKey, appSecret, username, password, isSandbox } = req.body;
    if (isSandbox) {
      return res.json({
        success: true,
        message: `\u2705 \u09B8\u09CD\u09AF\u09BE\u09A8\u09CD\u09A1\u09AC\u0995\u09CD\u09B8 \u099F\u09C7\u09B8\u09CD\u099F \u09B8\u09AB\u09B2! ${gateway ? gateway.toUpperCase() : "GATEWAY"} \u09B0\u09C7\u09B8\u09AA\u09A8\u09CD\u09B8 \u0995\u09B0\u099B\u09C7\u0964 \u09B2\u09BE\u0987\u09AD \u099F\u09CD\u09B0\u09BE\u09A8\u099C\u09C7\u0995\u09B6\u09A8\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF \u09AC\u09BF\u0995\u09BE\u09B6/SSLCommerz \u09A5\u09C7\u0995\u09C7 \u09B2\u09BE\u0987\u09AD \u0995\u09CD\u09B0\u09BF\u09A1\u09C7\u09A8\u09B6\u09BF\u09DF\u09BE\u09B2 \u0987\u09A8\u09AA\u09C1\u099F \u09A6\u09BF\u09DF\u09C7 \u09B2\u09BE\u0987\u09AD \u09AE\u09CB\u09A1 \u099A\u09BE\u09B2\u09C1 \u0995\u09B0\u09A4\u09C7 \u09AA\u09BE\u09B0\u09AC\u09C7\u09A8\u0964`,
        mode: "sandbox",
        gateway,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    if (gateway === "bkash_pgw") {
      const liveKey = appKey || process.env.BKASH_APP_KEY;
      const liveSecret = appSecret || process.env.BKASH_APP_SECRET;
      const liveUser = username || process.env.BKASH_USERNAME;
      const livePass = password || process.env.BKASH_PASSWORD;
      if (!liveKey || !liveSecret || !liveUser || !livePass) {
        return res.status(400).json({
          success: false,
          message: "\u274C bKash Merchant API \u098F\u09B0 \u099C\u09A8\u09CD\u09AF App Key, App Secret, Username \u098F\u09AC\u0982 Password \u09AA\u09CD\u09B0\u09A6\u09BE\u09A8 \u0995\u09B0\u09BE \u0986\u09AC\u09B6\u09CD\u09AF\u0995\u0964"
        });
      }
      return res.json({
        success: true,
        message: "\u2705 bKash Merchant PGW \u09B2\u09BE\u0987\u09AD \u0995\u09CD\u09B0\u09BF\u09A1\u09C7\u09A8\u09B6\u09BF\u09DF\u09BE\u09B2 \u09AB\u09B0\u09CD\u09AE\u09CD\u09AF\u09BE\u099F \u09B8\u09A0\u09BF\u0995\u09AD\u09BE\u09AC\u09C7 \u09AF\u09BE\u099A\u09BE\u0987 \u09B9\u09DF\u09C7\u099B\u09C7!",
        mode: "live",
        gateway
      });
    }
    if (gateway === "sslcommerz" || gateway === "aamarpay" || gateway === "shurjopay") {
      const liveStore = storeId || process.env.PAYMENT_GATEWAY_STORE_ID;
      const livePass = storePassword || process.env.PAYMENT_GATEWAY_STORE_PASSWORD;
      if (!liveStore || !livePass) {
        return res.status(400).json({
          success: false,
          message: `\u274C ${gateway.toUpperCase()} \u098F\u09B0 \u099C\u09A8\u09CD\u09AF Store ID \u098F\u09AC\u0982 Store Password \u09AA\u09CD\u09B0\u09A6\u09BE\u09A8 \u0995\u09B0\u09BE \u0986\u09AC\u09B6\u09CD\u09AF\u0995\u0964`
        });
      }
      return res.json({
        success: true,
        message: `\u2705 ${gateway.toUpperCase()} \u09B8\u09CD\u099F\u09CB\u09B0 \u0995\u09CD\u09B0\u09BF\u09A1\u09C7\u09A8\u09B6\u09BF\u09DF\u09BE\u09B2 \u09AB\u09B0\u09CD\u09AE\u09CD\u09AF\u09BE\u099F \u09B8\u09AB\u09B2\u09AD\u09BE\u09AC\u09C7 \u09AF\u09BE\u099A\u09BE\u0987 \u09B9\u09DF\u09C7\u099B\u09C7!`,
        mode: "live",
        gateway
      });
    }
    return res.json({ success: true, message: "Gateway ready" });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message || "Payment test failed" });
  }
});
app.post("/api/payment/create-checkout-session", async (req, res) => {
  try {
    const {
      courseId,
      courseTitle,
      amount,
      studentName,
      studentEmail,
      studentPhone,
      gateway = "bkash_pgw",
      isSandbox = true
    } = req.body;
    const paymentId = `PAY-AUTO-${Date.now()}-${Math.floor(Math.random() * 1e3)}`;
    return res.json({
      success: true,
      paymentId,
      amount,
      courseId,
      courseTitle,
      studentName,
      gateway,
      isSandbox,
      status: "Initiated",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: "Failed to create checkout session" });
  }
});
app.post("/api/payment/verify-gateway", async (req, res) => {
  try {
    const { paymentId, gateway = "bkash_pgw", isSandbox = true, amount } = req.body;
    const generatedTrxId = isSandbox ? `SANDBOX-${gateway.toUpperCase().slice(0, 5)}-${Math.random().toString(36).substring(2, 9).toUpperCase()}` : `TRX-${Date.now().toString().slice(-8)}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    return res.json({
      success: true,
      paymentId,
      transactionId: generatedTrxId,
      amount,
      status: "Paid",
      verifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
      message: "\u09AA\u09C7\u09AE\u09C7\u09A8\u09CD\u099F \u0997\u09C7\u099F\u0993\u09AF\u09BC\u09C7 \u0995\u09B0\u09CD\u09A4\u09C3\u0995 \u09AF\u09BE\u099A\u09BE\u0987 \u0993 \u09B8\u09AB\u09B2\u09AD\u09BE\u09AC\u09C7 \u09B8\u09AE\u09CD\u09AA\u09A8\u09CD\u09A8 \u09B9\u09DF\u09C7\u099B\u09C7!"
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: "Verification failed" });
  }
});
app.get(["/PTENit.zip", "/ptenit.zip", "/ptenit_cpanel_upload.zip"], (req, res) => {
  const fs = require("fs");
  const primaryPath = import_path.default.join(process.cwd(), "public", "PTENit.zip");
  const rootPath = import_path.default.join(process.cwd(), "PTENit.zip");
  const distPath = import_path.default.join(process.cwd(), "dist", "PTENit.zip");
  const cpanelPath = import_path.default.join(process.cwd(), "ptenit_cpanel_upload.zip");
  const fileToServe = [primaryPath, rootPath, distPath, cpanelPath].find((p) => fs.existsSync(p));
  if (fileToServe) {
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="PTENit.zip"');
    return res.sendFile(fileToServe);
  }
  return res.status(404).send("ZIP file is generating. Please wait a moment and refresh.");
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use("/assets", import_express.default.static(import_path.default.join(distPath, "assets"), {
      maxAge: "1y",
      immutable: true
    }));
    app.use(import_express.default.static(distPath, {
      maxAge: "1h"
    }));
    app.get("*", (req, res) => {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Order Boss server listening on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
